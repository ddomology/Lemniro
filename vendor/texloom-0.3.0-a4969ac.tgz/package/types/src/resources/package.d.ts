import type { Bundle, Resource } from '../schema.js';
import type { DeepReadonly, Diagnostic } from '../ir/operations.js';
export declare const RESOURCE_MEDIA_TYPE: 'application/vnd.texloom.resource+json';
export interface AssetEntry {
    id: string;
    kind: Resource['kind'];
    mediaType: typeof RESOURCE_MEDIA_TYPE;
    byteLength: number;
    sha256: string;
    bounds: [number, number, number, number];
    source: {
        kind: 'inline';
        data: string;
    } | {
        kind: 'external';
        uri: string;
        byteRange?: {
            offset: number;
            length: number;
        };
    };
}
export interface AssetManifest {
    version: 1;
    requiredFeatures: string[];
    entries: AssetEntry[];
}
export interface ScenePackage {
    contract: 'texloom-package/1';
    scene: Omit<Bundle, 'resources'>;
    assets: AssetManifest;
}
export interface AssetErrorContext {
    assetId?: string;
    uri?: string;
    path?: string;
    diagnostics?: readonly DeepReadonly<Diagnostic>[];
    cause?: unknown;
}
export declare class AssetError extends Error {
    readonly code: string;
    readonly assetId?: string;
    readonly uri?: string;
    readonly diagnostics: DeepReadonly<Diagnostic[]>;
    constructor(code: string, message: string, context?: AssetErrorContext);
}
export declare function validateAssetJson(input: unknown, path?: string): Diagnostic[];
export declare function validateAssetEntry(input: unknown, path?: string): Diagnostic[];
export declare function validateScenePackage(input: unknown): Diagnostic[];
export declare function snapshotScenePackage(input: unknown): DeepReadonly<ScenePackage>;
export declare function sha256Bytes(bytes: Uint8Array): Promise<string>;
