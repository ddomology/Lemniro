import { type Resource } from '../schema.js';
import type { DeepReadonly } from '../ir/operations.js';
import { type AssetEntry } from './package.js';
export type AssetResolver = (entry: DeepReadonly<AssetEntry>, context: {
    signal: AbortSignal;
}) => Promise<Uint8Array | ArrayBuffer>;
export interface AssetLease {
    readonly resource: DeepReadonly<Resource>;
    release(): void;
}
export interface AssetStoreStats {
    entries: number;
    pending: number;
    ready: number;
    waiters: number;
    leases: number;
    reservedBytes: number;
    disposed: boolean;
}
export interface AssetStore {
    acquire(entry: DeepReadonly<AssetEntry>, signal?: AbortSignal): Promise<AssetLease>;
    stats(): Readonly<AssetStoreStats>;
    dispose(): void;
}
export interface AssetStoreOptions {
    resolver?: AssetResolver;
    maxAssetBytes?: number;
    maxTotalBytes?: number;
}
export declare function createAssetStore(options?: AssetStoreOptions): AssetStore;
