import type { PathGeometry, PathPoint } from './path-geometry.js';
export declare function validatePathGeometry(value: unknown): {
    path: string;
    message: string;
}[];
export declare function parseGeometryProperty(property: unknown): {
    contour: string;
    segment?: string;
    key: 'start' | 'to' | 'c1' | 'c2';
} | undefined;
export declare function geometryPointSlot(geometry: PathGeometry | undefined, property: string): {
    get(): PathPoint;
    set(value: PathPoint): void;
} | undefined;
