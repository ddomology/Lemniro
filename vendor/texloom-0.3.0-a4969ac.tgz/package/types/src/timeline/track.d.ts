import type { Track, TrackValue } from '../schema.js';
import type { Easing } from './ast.js';
export declare function trackSegmentEasing(track: Track, index: number): Easing;
export declare function trackLeftValue(track: Track, index: number): TrackValue;
export declare function mixTrackValues(a: TrackValue, b: TrackValue, t: number): TrackValue;
export declare function evaluateTrack(track: Track, time: number): TrackValue;
export declare function trackHasSingularScale(track: Track): boolean;
