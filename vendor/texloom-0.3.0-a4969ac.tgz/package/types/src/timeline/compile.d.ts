import { type Bundle } from '../schema.js';
import { type DeepReadonly } from '../ir/operations.js';
import type { TimelineProgram, CompiledTimeline } from './ast.js';
export declare function compileTimeline(program: TimelineProgram, bundle: Bundle): DeepReadonly<CompiledTimeline>;
export declare function lowerTimeline(program: TimelineProgram, bundle: Bundle): Bundle;
