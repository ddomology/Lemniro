import type { Track, TrackValue, Node } from '../schema.js';
import type { CorrespondenceOptions } from '../geometry/correspondence.js';
import type { MorphProgram } from './morph.js';
import type { MathTransformProgram, MathTransformOptions } from './math-transform.js';
import type { Resource } from '../schema.js';
import type { Diagnostic, SourceSpan } from '../ir/operations.js';
export type Easing = 'linear' | 'smooth' | 'step';
interface Source {
    id?: string;
    sourceSpan?: SourceSpan;
}
export type TimelineNode = Source & ({
    kind: 'sequence' | 'parallel';
    children: TimelineNode[];
} | {
    kind: 'stagger';
    children: TimelineNode[];
    lag: number;
} | {
    kind: 'wait';
    duration: number;
} | {
    kind: 'cue';
    name: string;
} | {
    kind: 'tween';
    target: string;
    property: string;
    duration: number;
    from?: TrackValue;
    to: TrackValue;
    easing?: Easing;
} | {
    kind: 'set';
    target: string;
    property: string;
    value: TrackValue;
} | {
    kind: 'morph';
    id: string;
    source: string;
    destination: string;
    duration: number;
    easing?: Easing;
    correspondence: CorrespondenceOptions;
} | {
    kind: 'math-transform';
    id: string;
    source: string;
    destination: string;
    duration: number;
    easing?: Easing;
    correspondence: MathTransformOptions;
} | {
    kind: 'clone';
    id: string;
    source: string;
} | {
    kind: 'enter' | 'exit';
    target: string;
    duration: number;
    easing?: Easing;
    mode?: 'fade' | 'create';
});
export interface TimelineProgram {
    version: 1;
    origin?: number;
    root: TimelineNode;
}
export interface TimelineCue {
    name: string;
    time: number;
    sourceSpan?: SourceSpan;
}
export interface TimelineClip {
    id: string;
    kind: 'tween' | 'set';
    target: string;
    property: string;
    start: number;
    end: number;
    sourceSpan?: SourceSpan;
}
export interface TimelineMetadata {
    version: 1;
    origin: number;
    end: number;
    duration: number;
    cues: TimelineCue[];
    clips: TimelineClip[];
}
export interface CompiledTimeline {
    tracks: Track[];
    cues: TimelineCue[];
    clips: TimelineClip[];
    origin: number;
    end: number;
    duration: number;
    generatedNodes?: Node[];
    generatedResources?: Record<string, Resource>;
    morphs?: MorphProgram;
    mathTransforms?: MathTransformProgram;
}
export declare const TIMELINE_MAX_DEPTH = 32, TIMELINE_MAX_NODES = 4096;
export declare function validateTimelineMetadata(value: unknown, sceneDuration: number): Diagnostic[];
export {};
