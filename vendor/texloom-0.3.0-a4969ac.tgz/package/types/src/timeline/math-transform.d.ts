import { type Bundle, type Node, type TexNode, type VectorResource } from '../schema.js';
import { type Diagnostic, type SourceSpan, type DeepReadonly } from '../ir/operations.js';
import { type MathCorrespondenceOptions, type PreparedMathCorrespondence } from '../operations/text-parts.js';
import type { PropertyAccess } from '../operations/properties.js';
export interface MathTransformOptions extends MathCorrespondenceOptions {
    labels: {
        source: string;
        target: string;
    };
}
export interface MathTransformOperation {
    id: string;
    instance: string;
    source: string;
    destination: string;
    correspondence: MathTransformOptions;
    sourceSpan?: SourceSpan;
}
export interface MathTransformProgram {
    version: 1;
    operations: MathTransformOperation[];
}
export interface MathTransformReport {
    progress: number;
    state: 'source' | 'transition' | 'target';
    active: boolean;
    sourceText: string;
    targetText: string;
    description: string;
    retention: 'replace' | 'keep-source';
}
export type MathTransformEvaluation = Readonly<Record<string, DeepReadonly<MathTransformReport>>>;
export interface PreparedMathTransform {
    operation: DeepReadonly<MathTransformOperation>;
    path: string;
    reads: readonly PropertyAccess[];
    writes: readonly PropertyAccess[];
    apply(nodes: Map<string, Node>): DeepReadonly<MathTransformReport>;
}
export declare function mathTransformNames(id: string, count: number): {
    source: string;
    target: string;
    sourceRest: string;
    targetRest: string;
    pairs: {
        source: string;
        target: string;
    }[];
};
interface Built {
    nodes: Node[];
    resources: Record<string, VectorResource>;
    prepared: DeepReadonly<PreparedMathCorrespondence>;
    source: TexNode;
    target: TexNode;
    opacity: number;
}
export declare function createMathTransformInstance(operation: MathTransformOperation, bundle: Bundle): Built;
export declare function validateMathTransformProgram(input: unknown, bundle: Bundle): Diagnostic[];
export declare function validateMathTransformProgramInContext(input: unknown, bundle: Bundle): Diagnostic[];
export declare function prepareMathTransformProgram(input: MathTransformProgram, bundle: Bundle): {
    operations: readonly PreparedMathTransform[];
};
export {};
