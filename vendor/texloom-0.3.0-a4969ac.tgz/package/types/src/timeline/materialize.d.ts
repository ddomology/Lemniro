import type { Bundle, Node, Resource } from '../schema.js';
import type { TimelineProgram } from './ast.js';
import type { MorphProgram } from './morph.js';
import { type MathTransformProgram } from './math-transform.js';
export declare function materializeTimeline(program: TimelineProgram, input: Bundle): {
    program: TimelineProgram;
    bundle: Bundle;
    generatedNodes: Node[];
    generatedResources: Record<string, Resource>;
    morphs?: MorphProgram;
    mathTransforms?: MathTransformProgram;
};
