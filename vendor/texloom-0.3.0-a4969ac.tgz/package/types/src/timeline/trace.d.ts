import { type Bundle, type EvaluatedFrame } from '../schema.js';
import { type Diagnostic, type SourceSpan, type DeepReadonly } from '../ir/operations.js';
import type { ExecutionAccess } from '../operations/plan.js';
import type { ExpressionValue } from '../fields/ast.js';
export interface TraceOperation {
    id: string;
    target: string;
    source: {
        kind: 'node';
        node: string;
        property: 'position';
        space: {
            kind: 'scene';
        };
    };
    domain: [number, number];
    step: number;
    tolerance?: number;
    maxDepth?: number;
    maxSamples?: number;
    seed: 0;
    missing: 'break';
    reveal: 'progress' | 'full';
    sourceSpan?: SourceSpan;
}
export interface TraceProgram {
    version: 1;
    operations: TraceOperation[];
}
export interface TraceGap {
    domain: [number, number];
    reason: 'hidden' | 'missing' | 'visibility-boundary';
}
export interface TraceReport {
    domain: [number, number];
    step: number;
    tolerance: number;
    seed: 0;
    sampleCount: number;
    segmentCount: number;
    contourCount: number;
    maskedIntervals: number;
    maxDepthReached: number;
    maxObservedError: number;
    maxAcceptedError: number;
    qualityMetric: 'observed-probes';
    gaps: TraceGap[];
    reveal: {
        mode: 'progress' | 'full';
        time: number;
        end: number;
        segmentCount: number;
        contourCount: number;
    };
}
export type TraceEvaluation = Readonly<Record<string, DeepReadonly<TraceReport>>>;
export interface PreparedTraceProgram {
    apply(frame: EvaluatedFrame, parameters?: Readonly<Record<string, ExpressionValue>>): TraceEvaluation;
}
type BaseEvaluator = (time: number, parameters?: Readonly<Record<string, ExpressionValue>>) => EvaluatedFrame;
export declare function validateTraceProgram(input: unknown, bundle: Bundle): Diagnostic[];
export declare function validateTraceProgramInContext(input: unknown, bundle: Bundle): Diagnostic[];
export declare function prepareTraceProgram(input: TraceProgram, bundle: Bundle, evaluate: BaseEvaluator, accesses?: readonly DeepReadonly<ExecutionAccess>[]): PreparedTraceProgram;
export {};
