import { type Bundle, type Node } from '../schema.js';
import { type Diagnostic, type SourceSpan, type DeepReadonly } from '../ir/operations.js';
import { type PropertyAccess } from '../operations/properties.js';
import { type CorrespondenceOptions, type CorrespondenceReport } from '../geometry/correspondence.js';
export interface MorphOperation {
    id: string;
    source: string;
    destination: string;
    instance: string;
    correspondence: CorrespondenceOptions;
    sourceSpan?: SourceSpan;
}
export interface MorphProgram {
    version: 1;
    operations: MorphOperation[];
}
export interface MorphReport {
    progress: number;
    correspondence: CorrespondenceReport;
}
export type MorphEvaluation = Readonly<Record<string, DeepReadonly<MorphReport>>>;
export interface PreparedMorph {
    readonly operation: DeepReadonly<MorphOperation>;
    readonly path: string;
    readonly reads: readonly PropertyAccess[];
    readonly writes: readonly PropertyAccess[];
    apply(nodes: Map<string, Node>): DeepReadonly<MorphReport>;
}
export interface PreparedMorphProgram {
    readonly operations: readonly PreparedMorph[];
}
export declare function morphWrites(instance: string): PropertyAccess[];
export declare function validateMorphProgram(input: unknown, bundle: Bundle): Diagnostic[];
export declare function validateMorphProgramInContext(input: unknown, bundle: Bundle): Diagnostic[];
export declare function prepareMorphProgram(input: MorphProgram, bundle: Bundle): PreparedMorphProgram;
