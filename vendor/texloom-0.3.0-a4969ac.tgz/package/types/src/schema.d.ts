import type { PathGeometry } from './path-geometry.js';
import type { ArrowOptions, ArrowGeometryResult } from './geometry/arrowheads.js';
import type { Diagnostic, OperationGraph, SourceSpan } from './ir/operations.js';
import type { ExpressionProgram } from './fields/ast.js';
import type { FieldProgram, FieldEvaluation } from './fields/types.js';
import { type DeformationProgram, type DeformationEvaluation } from './operations/deform.js';
import { type PlotProgram, type PlotEvaluation } from './operations/plot.js';
import { type TimelineMetadata, type Easing } from './timeline/ast.js';
import { type MorphProgram, type MorphEvaluation } from './timeline/morph.js';
import { type MathTransformProgram, type MathTransformEvaluation } from './timeline/math-transform.js';
import { type TextParts } from './ir/text-parts.js';
import { type TraceProgram, type TraceEvaluation } from './timeline/trace.js';
export type { Diagnostic, SourceSpan } from './ir/operations.js';
export interface Style {
    fill?: string;
    stroke?: string;
    strokeWidth?: number;
    opacity?: number;
    dash?: number[];
    fillOpacity?: number;
    strokeOpacity?: number;
    miterLimit?: number;
    lineCap?: 'butt' | 'round' | 'square';
    lineJoin?: 'miter' | 'round' | 'bevel';
    fillRule?: 'nonzero' | 'evenodd';
}
export interface Transform {
    translate?: [number, number];
    rotate?: number;
    scale?: [number, number];
}
export interface Clip {
    d: string;
    fillRule?: 'nonzero' | 'evenodd';
}
export interface NodeBase {
    id: string;
    parent?: string;
    transform?: Transform;
    style?: Style;
    clip?: Clip;
    visible?: boolean;
    source?: Record<string, unknown>;
}
export interface MeasuredAnchorMetrics {
    kind: 'pgf';
    shape: string;
    logicalTextBox: [number, number, number, number];
    textMetrics: {
        width: number;
        height: number;
        depth: number;
    };
    innerSep: [number, number];
    outerSep: [number, number];
    alignment: string;
    revision: string;
}
export interface GroupNode extends NodeBase {
    kind: 'group';
    anchors?: Record<string, [number, number]>;
    anchorMetrics?: MeasuredAnchorMetrics;
    morphProgress?: number;
    mathProgress?: number;
}
export interface ResolvedPath {
    start: [number, number];
    c1: [number, number];
    c2: [number, number];
    end: [number, number];
}
export interface PathNode extends NodeBase {
    kind: 'path';
    d: string;
    arrowStart?: boolean;
    arrowEnd?: boolean;
    arrowSize?: number;
    resolvedPath?: ResolvedPath;
    geometry?: PathGeometry;
    reveal?: number;
    revealMode?: 'parameter' | 'length';
    pathTolerance?: number;
    arrows?: ArrowOptions;
    resolvedArrows?: ArrowGeometryResult;
}
export interface EllipseNode extends NodeBase {
    kind: 'ellipse';
    cx: number;
    cy: number;
    rx: number;
    ry: number;
}
export interface PointNode extends NodeBase {
    kind: 'point';
    x: number;
    y: number;
    r: number;
    phase?: number;
    progress?: number;
}
export interface LineNode extends NodeBase {
    kind: 'line';
    x1: number;
    y1: number;
    x2: number;
    y2: number;
}
export interface TexNode extends NodeBase {
    kind: 'tex';
    resourceId: string;
    x: number;
    y: number;
    scale?: number;
}
export interface FieldNode extends NodeBase {
    kind: 'field';
    resourceId: string;
    x: number;
    y: number;
    width: number;
    height: number;
    values?: number[];
}
export type Node = GroupNode | PathNode | EllipseNode | PointNode | LineNode | TexNode | FieldNode;
export type Matrix = [number, number, number, number, number, number];
export interface PaintItem {
    kind: 'path' | 'group';
    d?: string;
    transform?: Matrix;
    style?: Style;
    clip?: Clip & {
        transform?: Matrix;
    };
    children?: PaintItem[];
}
export interface VectorResource {
    kind: 'vector';
    items: PaintItem[];
    metrics: {
        width: number;
        height: number;
        depth: number;
    };
    inkBounds: [number, number, number, number];
    sourceTex?: string;
    glyphs?: unknown[];
    capabilities?: string[];
    textParts?: TextParts;
}
export interface ScalarFieldResource {
    kind: 'scalar-field';
    columns: number;
    rows: number;
    times: number[];
    samples: number[][];
    range: [number, number];
    interpolation: 'linear' | 'step';
    provenance?: Record<string, unknown>;
}
export type Resource = VectorResource | ScalarFieldResource;
export type TrackValue = number | number[];
export interface Track {
    target: string;
    property: string;
    keys: [number, TrackValue][];
    interpolation?: Easing;
    segmentEasings?: Easing[];
    leftValues?: (TrackValue | null)[];
    sourceSpan?: SourceSpan;
}
export type Relation = ({
    type: 'pointOnEllipse';
    target: string;
    source: string;
} | {
    type: 'tangent';
    target: string;
    source: string;
    point: string;
    length: number;
} | {
    type: 'attach';
    target: string;
    source: string;
    offset: [number, number];
} | {
    type: 'lineBetween';
    target: string;
    a: string;
    b: string;
} | {
    type: 'pointOnPath';
    target: string;
    source: string;
    mode?: 'parameter' | 'length';
    tolerance?: number;
} | {
    type: 'pathDirection';
    target: string;
    source: string;
    point: string;
    length: number;
    normal?: boolean;
} | {
    type: 'connect';
    target: string;
    from: {
        node: string;
        anchor: string;
    };
    to: {
        node: string;
        anchor: string;
    };
    bend?: number;
} | {
    type: 'pathLabel';
    target: string;
    path: string;
    position: number;
    offset: number;
    rotate?: boolean;
}) & {
    sourceSpan?: SourceSpan;
};
export interface Camera {
    x: number;
    y: number;
    zoom: number;
    rotation?: number;
}
export interface Bundle {
    version: '0.1' | '0.2' | '0.3';
    title: string;
    duration: number;
    units: 'bp';
    viewport: {
        width: number;
        height: number;
    };
    nodes: Node[];
    resources: Record<string, Resource>;
    tracks: Track[];
    relations: Relation[];
    camera: Camera;
    document?: {
        blocks: unknown[];
    };
    provenance?: Record<string, unknown>;
    diagnostics?: Diagnostic[];
    operationGraph?: OperationGraph;
    expressions?: ExpressionProgram;
    fields?: FieldProgram;
    deformations?: DeformationProgram;
    plots?: PlotProgram;
    timeline?: TimelineMetadata;
    morphs?: MorphProgram;
    mathTransforms?: MathTransformProgram;
    traces?: TraceProgram;
}
export interface EvaluatedFrame {
    time: number;
    viewport: Bundle['viewport'];
    camera: Camera;
    nodes: Node[];
    resources: Record<string, Resource>;
    fields?: FieldEvaluation;
    deformations?: DeformationEvaluation;
    plots?: PlotEvaluation;
    morphs?: MorphEvaluation;
    mathTransforms?: MathTransformEvaluation;
    traces?: TraceEvaluation;
    shapes?: import('./operations/shapes.js').ShapeEvaluation;
    anchors?: import('./operations/anchors.js').AnchorEvaluation;
    curves?: import('./operations/curves.js').CurveEvaluation;
    intersections?: import('./operations/intersections.js').IntersectionEvaluation;
}
interface PropertySpec {
    size?: number;
    min?: number;
    strictMin?: number;
    max?: number;
}
export declare function propertySpec(kind: string, property: string): PropertySpec | undefined;
export declare function relationOutputs(relation: Relation): string[];
export declare function relationSources(relation: Relation): string[];
export declare function validateBundle(input: unknown): Diagnostic[];
export declare class BundleValidationError extends Error {
    readonly diagnostics: Diagnostic[];
    constructor(diagnostics: Diagnostic[]);
}
export declare function assertBundle(bundle: unknown): asserts bundle is Bundle;
