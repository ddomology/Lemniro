import { type DeepReadonly, type SourceSpan } from '../ir/operations.js';
import type { CompiledExpression, ExpressionType, ExpressionValue, ParameterDefinition } from './ast.js';
import type { FieldAttribute, FieldContext } from './types.js';
export interface CompiledFieldExpression extends CompiledExpression {
    readonly attributeTypes: Readonly<Record<string, DeepReadonly<ExpressionType>>>;
}
export declare function compileFieldExpression(text: string, parameterDefinitions?: Readonly<Record<string, ParameterDefinition>>, attributeTypes?: Readonly<Record<string, ExpressionType>>, sourceSpan?: SourceSpan): CompiledFieldExpression;
export declare function evaluateFieldExpression(compiled: CompiledFieldExpression, context: DeepReadonly<FieldContext>, parameters?: Readonly<Record<string, ExpressionValue>>, attributes?: Readonly<Record<string, DeepReadonly<FieldAttribute>>>, position?: 'current' | 'original'): DeepReadonly<FieldAttribute>;
