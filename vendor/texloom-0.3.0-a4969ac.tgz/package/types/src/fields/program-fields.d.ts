import { type Bundle, type Node, type Camera } from '../schema.js';
import { type Diagnostic } from '../ir/operations.js';
import { type PropertyAccess } from '../operations/properties.js';
import type { ExpressionValue } from './ast.js';
import type { FieldProgram, FieldEvaluation } from './types.js';
export declare function fieldBindingProperties(program: FieldProgram, nodes: ReadonlyMap<string, Node>): PropertyAccess[];
export declare function validateFieldProgram(program: unknown, bundle: Bundle): Diagnostic[];
export declare function validateFieldProgramInContext(program: unknown, bundle: Bundle): Diagnostic[];
export interface PreparedFieldProgram {
    readonly reads: readonly PropertyAccess[];
    readonly writes: readonly PropertyAccess[];
    sample(nodes: Map<string, Node>, time: number, parameters: Readonly<Record<string, ExpressionValue>>): FieldEvaluation;
    apply(result: FieldEvaluation, nodes: Map<string, Node>, camera: Camera): void;
}
export declare function prepareFieldProgram(input: FieldProgram, bundle: Bundle): PreparedFieldProgram;
