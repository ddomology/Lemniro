import { type DeepReadonly } from '../ir/operations.js';
import { type PathGeometry } from '../path-geometry.js';
import type { FieldContext, FieldDomainDeclaration } from './types.js';
export declare function assertFieldContext(context: DeepReadonly<FieldContext>): void;
export declare function createFieldContext(declaration: DeepReadonly<FieldDomainDeclaration>, originalGeometry: DeepReadonly<PathGeometry>, currentGeometry: DeepReadonly<PathGeometry>, time: number): DeepReadonly<FieldContext>;
