import { type SourceSpan } from '../ir/operations.js';
import type { CompiledExpression, ExpressionContext, ExpressionType, ExpressionValue, ParameterDefinition } from './ast.js';
export declare function compileExpression(text: string, parameters?: Readonly<Record<string, ParameterDefinition>>, sourceSpan?: SourceSpan, variables?: Readonly<Record<string, ExpressionType>>): CompiledExpression;
export declare function evaluateExpression(compiled: CompiledExpression, context: ExpressionContext): ExpressionValue;
