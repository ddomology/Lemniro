import { type SourceSpan } from '../ir/operations.js';
import type { ExpressionNode } from './ast.js';
export declare function parseExpression(text: string, sourceSpan?: SourceSpan): ExpressionNode;
