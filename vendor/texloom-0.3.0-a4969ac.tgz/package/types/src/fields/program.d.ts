import type { Bundle } from '../schema.js';
import { type Diagnostic, type LiteralValue, type DeepReadonly, type SpaceRef } from '../ir/operations.js';
import type { CompiledExpression, ExpressionBinding, ExpressionProgram, ExpressionValue, Unit } from './ast.js';
export interface ExpressionDestination {
    kind: 'scalar' | 'boolean' | 'vec2';
    unit: Unit;
    role?: 'point' | 'vector';
    space?: SpaceRef;
}
export interface PreparedExpressionBinding {
    readonly binding: DeepReadonly<ExpressionBinding>;
    readonly expression: CompiledExpression;
    readonly destination: DeepReadonly<ExpressionDestination>;
    readonly path: string;
}
export interface PreparedExpressionProgram {
    readonly bindings: readonly PreparedExpressionBinding[];
    resolveParameters(overrides?: Readonly<Record<string, ExpressionValue>>): Record<string, ExpressionValue>;
}
export declare function validateExpressionProgram(program: unknown, bundle: Bundle): Diagnostic[];
export declare function validateExpressionProgramInContext(program: unknown, bundle: Bundle): Diagnostic[];
export declare function prepareExpressionProgram(program: ExpressionProgram | undefined, bundle: Bundle): PreparedExpressionProgram;
export declare function prepareParameterResolver(input: ExpressionProgram['parameters']): PreparedExpressionProgram['resolveParameters'];
export declare function evaluateExpressionBinding(prepared: PreparedExpressionBinding, time: number, parameters: Record<string, ExpressionValue>): LiteralValue | boolean;
