import type { Bundle, EvaluatedFrame } from './schema.js';
import type { ExpressionValue } from './fields/ast.js';
export declare function evaluate(bundle: Bundle, time: number, parameters?: Readonly<Record<string, ExpressionValue>>): EvaluatedFrame;
export declare function createEvaluator(bundle: Bundle): (time: number, parameters?: Readonly<Record<string, ExpressionValue>>) => EvaluatedFrame;
export declare function createEvaluatorWithSharedResources(bundle: Bundle): ReturnType<typeof createEvaluator>;
