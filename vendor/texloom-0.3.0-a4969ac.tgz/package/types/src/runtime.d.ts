import { type Bundle, type EvaluatedFrame } from './schema.js';
import type { ExpressionValue } from './fields/ast.js';
import { type CapabilityProfile, type RenderFeature } from './capabilities.js';
import type { TimelineMetadata } from './timeline/ast.js';
import type { DeepReadonly, SourceSpan } from './ir/operations.js';
import { type ScenePackage, type AssetEntry } from './resources/package.js';
import { type AssetStore, type AssetResolver } from './resources/store.js';
export interface SceneManifest {
    readonly contract: 'texloom-runtime/1';
    readonly sceneVersion: Bundle['version'];
    readonly title: string;
    readonly duration: number;
    readonly viewport: Readonly<Bundle['viewport']>;
    readonly features: readonly RenderFeature[];
    readonly timeline?: DeepReadonly<TimelineMetadata>;
    readonly assets?: readonly DeepReadonly<Omit<AssetEntry, 'source'>>[];
}
export interface SceneRuntime {
    readonly manifest: SceneManifest;
    sample(seconds: number, parameters?: Readonly<Record<string, ExpressionValue>>): EvaluatedFrame;
    require(profile: CapabilityProfile): void;
}
export declare function prepareScene(bundle: Bundle): SceneRuntime;
export type PreparationState = 'preparing' | 'ready' | 'failed' | 'disposed';
export interface PreparedSceneRuntime extends SceneRuntime {
    readonly state: 'ready' | 'disposed';
    dispose(): void;
}
export interface ScenePreparation {
    readonly state: PreparationState;
    readonly error: Error | undefined;
    readonly ready: Promise<PreparedSceneRuntime>;
    dispose(): void;
}
export interface PrepareSceneOptions {
    assetResolver?: AssetResolver;
    assetStore?: AssetStore;
    signal?: AbortSignal;
    profile?: CapabilityProfile;
}
export declare class ScenePreparationError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function beginPrepareScene(input: Bundle | ScenePackage, options?: PrepareSceneOptions): ScenePreparation;
export declare function prepareSceneAsync(input: Bundle | ScenePackage, options?: PrepareSceneOptions): Promise<PreparedSceneRuntime>;
export interface ClipTiming {
    start: number;
    sourceStart?: number;
    rate?: number;
    duration?: number;
    before?: 'hidden' | 'hold';
    after?: 'hidden' | 'hold';
}
export interface ClipSample {
    hostTime: number;
    sourceTime: number;
    phase: 'before' | 'active' | 'after';
    visible: boolean;
    frame: EvaluatedFrame | null;
}
export interface SceneClip {
    readonly timing: Readonly<Required<ClipTiming>>;
    readonly cues: readonly ClipCue[];
    sample(hostSeconds: number, parameters?: Readonly<Record<string, ExpressionValue>>): ClipSample;
}
export interface ClipCue {
    readonly name: string;
    readonly sourceTime: number;
    readonly hostTime: number;
    readonly sourceSpan?: DeepReadonly<SourceSpan>;
}
export declare function bindSceneClip(runtime: SceneRuntime, input: ClipTiming): SceneClip;
