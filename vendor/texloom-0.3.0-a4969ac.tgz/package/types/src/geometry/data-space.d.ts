import { type PathGeometry, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface CartesianConfig {
    origin: PathPoint;
    width: number;
    height: number;
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
    xScale?: 'linear' | 'log';
    yScale?: 'linear' | 'log';
    logBase?: number;
    xStep?: number;
    yStep?: number;
    tickSize?: number;
    maxTicks?: number;
}
export interface TickFormatOptions {
    notation?: 'decimal' | 'scientific';
    precision?: number;
}
export interface CartesianAxes {
    xAxis: PathGeometry;
    yAxis: PathGeometry;
    ticks: PathGeometry;
    grid: PathGeometry;
    xTicks: number[];
    yTicks: number[];
}
export interface CartesianMapping {
    dataToScene(x: number, y: number): PathPoint;
    sceneToData(point: DeepReadonly<PathPoint>): PathPoint;
}
export declare const MAX_AXIS_TICKS = 4096;
export type AxisErrorCode = 'AXIS_OPTIONS' | 'AXIS_DOMAIN' | 'AXIS_PRECISION' | 'AXIS_RANGE' | 'AXIS_BUDGET' | 'AXIS_COORDINATE' | 'AXIS_FORMAT' | 'AXIS_LABEL_DUPLICATE';
export declare function createCartesianMapping(config: DeepReadonly<CartesianConfig>): CartesianMapping;
export declare function createCartesianAxes(config: DeepReadonly<CartesianConfig>): DeepReadonly<CartesianAxes>;
export declare function cartesianLabelPosition(config: DeepReadonly<CartesianConfig>, x: number, y: number, axisName: 'point' | 'x' | 'y', respectTicks?: boolean): {
    position: PathPoint;
    visible: boolean;
};
export declare function formatTick(value: number, options?: DeepReadonly<TickFormatOptions>): string;
export declare function formatTickLabels(values: readonly number[], options?: DeepReadonly<TickFormatOptions>): string[];
