import { type PathGeometry, type PathPoint, type PathProgressMode } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export type CurveScope = {
    kind: 'whole';
} | {
    kind: 'contour';
    contourId: string;
};
export interface CurveOptions {
    mode?: PathProgressMode;
    scope?: CurveScope;
    tolerance?: number;
}
export interface CurveTrimOptions extends CurveOptions {
    wrap?: boolean;
}
export interface CurveResampleOptions extends CurveOptions {
    count?: number;
    spacing?: number;
}
export type CurveJoinPolicy = 'separate' | 'coincident' | 'bridge';
export interface CurveSourceRef {
    geometryId?: string;
    contourId: string;
    segmentId: string;
    parameterInterval: [number, number];
    closing: boolean;
}
export interface CurveProvenanceSegment {
    contourId: string;
    segmentId: string;
    mapping: 'exact' | 'approximate' | 'synthetic';
    sources: CurveSourceRef[];
}
export interface CurveProvenance {
    version: 1;
    segments: CurveProvenanceSegment[];
}
export interface CurveReport {
    operation: 'trim' | 'reverse' | 'resample' | 'join';
    representation: 'exact' | 'polyline';
    inputSegments: number;
    outputSegments: number;
    tolerance: number;
    sampleCount?: number;
    spacing?: number;
    policy?: CurveJoinPolicy;
}
export interface CurveResult {
    geometry: DeepReadonly<PathGeometry>;
    provenance: DeepReadonly<CurveProvenance>;
    report: DeepReadonly<CurveReport>;
}
export interface CurveSample {
    position: PathPoint;
    tangent: PathPoint;
    length: number;
    totalLength: number;
    contourId: string;
    segmentId: string;
    localParameter: number;
    mapping: 'exact' | 'approximate' | 'synthetic';
    sourceRefs: CurveSourceRef[];
}
export interface CurveInput {
    geometry: DeepReadonly<PathGeometry>;
    provenance?: DeepReadonly<CurveProvenance>;
}
export interface TransformedCurveInput {
    geometry: DeepReadonly<PathGeometry>;
    provenance: DeepReadonly<CurveProvenance>;
}
export declare function seedCurveProvenance(input: DeepReadonly<PathGeometry>, geometryId?: string): DeepReadonly<CurveProvenance>;
export declare function assertCurveProvenance(input: DeepReadonly<PathGeometry>, value: unknown): asserts value is DeepReadonly<CurveProvenance>;
export declare function transformCurveInput(input: CurveInput, matrix: readonly [number, number, number, number, number, number]): TransformedCurveInput;
export declare function sampleCurveGeometry(input: DeepReadonly<PathGeometry>, p: number, options?: CurveOptions, provenance?: DeepReadonly<CurveProvenance>): CurveSample;
export declare function trimCurveGeometry(input: DeepReadonly<PathGeometry>, start: number, end: number, options?: CurveTrimOptions, provenance?: DeepReadonly<CurveProvenance>): CurveResult;
export declare function reverseCurveGeometry(input: DeepReadonly<PathGeometry>, options?: CurveOptions, provenance?: DeepReadonly<CurveProvenance>): CurveResult;
export declare function resampleCurveGeometry(input: DeepReadonly<PathGeometry>, options: CurveResampleOptions, provenance?: DeepReadonly<CurveProvenance>): CurveResult;
export declare function joinCurveGeometries(inputs: readonly CurveInput[], options: {
    policy: CurveJoinPolicy;
    tolerance?: number;
}): CurveResult;
