import type { DeepReadonly } from '../ir/operations.js';
export type CubicPoint = readonly [number, number];
export type CubicControls = readonly [CubicPoint, CubicPoint, CubicPoint, CubicPoint];
export interface CubicIntersectionOptions {
    positionTolerance: number;
    parameterTolerance: number;
    maxWork: number;
    maxDepth: number;
}
export interface CubicIntersectionPoint {
    parameterA: number;
    parameterB: number;
    contact: 'crossing' | 'tangent' | 'endpoint' | 'degenerate';
}
export interface CubicIntersectionOverlap {
    parameterA: [number, number];
    parameterB: [number, number];
    orientation: 1 | -1;
}
export interface CubicIntersectionResult {
    points: CubicIntersectionPoint[];
    overlaps: CubicIntersectionOverlap[];
    work: number;
    maxDepthReached: number;
}
export declare function intersectCubicSegments(a: CubicControls, b: CubicControls, options: CubicIntersectionOptions): DeepReadonly<CubicIntersectionResult>;
