import { type DeepReadonly, type Diagnostic } from '../ir/operations.js';
import type { PathGeometry, PathPoint, PathBounds } from '../path-geometry.js';
export type Primitive2D = {
    kind: 'circle';
    center: [number, number];
    radius: number;
} | {
    kind: 'ellipse';
    center: [number, number];
    rx: number;
    ry: number;
} | {
    kind: 'arc';
    center: [number, number];
    rx: number;
    ry: number;
    startAngle: number;
    sweepAngle: number;
} | {
    kind: 'rectangle';
    origin: [number, number];
    width: number;
    height: number;
} | {
    kind: 'roundedRectangle';
    origin: [number, number];
    width: number;
    height: number;
    cornerRadius: number;
} | {
    kind: 'polyline';
    points: [number, number][];
    closed: boolean;
};
export interface PrimitivePathOptions {
    profile: 'cubic' | 'polyline';
    tolerance: number;
    maxSegments: number;
}
export interface PrimitivePathReport {
    profile: 'cubic' | 'polyline';
    tolerance: number;
    errorBound: number;
    segments: number;
    closed: boolean;
    analyticKind: Primitive2D['kind'];
    precision: 'float64-with-roundoff-guard';
    spans: {
        segmentId: string;
        parameterInterval: [number, number];
        errorBound: number;
        source: 'line' | 'arc';
    }[];
}
export interface PrimitivePathResult {
    geometry: DeepReadonly<PathGeometry>;
    report: DeepReadonly<PrimitivePathReport>;
}
export declare function validatePrimitive(input: unknown): Diagnostic[];
export declare function samplePrimitive(primitive: DeepReadonly<Primitive2D>, parameter: number): {
    point: PathPoint;
    tangent: PathPoint;
};
export declare function primitiveBounds(primitive: DeepReadonly<Primitive2D>): PathBounds;
export declare function primitiveToPath(primitive: DeepReadonly<Primitive2D>, options: PrimitivePathOptions): PrimitivePathResult;
