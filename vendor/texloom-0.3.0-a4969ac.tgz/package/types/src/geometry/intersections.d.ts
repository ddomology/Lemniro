import { type PathGeometry, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export type IntersectionMode = 'segment' | 'line';
export interface IntersectionOptions {
    modeA?: IntersectionMode;
    modeB?: IntersectionMode;
    positionTolerance?: number;
    parameterTolerance?: number;
    maxPairs?: number;
    maxResults?: number;
}
export interface IntersectionSegmentRef {
    contourId: string;
    segmentId: string;
    contourIndex: number;
    segmentIndex: number;
    closing: boolean;
}
export type IntersectionContact = 'crossing' | 'tangent' | 'endpoint' | 'degenerate';
export interface IntersectionIncident {
    a: IntersectionSegmentRef;
    b: IntersectionSegmentRef;
    parameterA: number;
    parameterB: number;
    contact: IntersectionContact;
}
export interface IntersectionPoint {
    point: PathPoint;
    incidents: IntersectionIncident[];
}
export interface IntersectionOverlap {
    a: IntersectionSegmentRef;
    b: IntersectionSegmentRef;
    parameterA: [number | null, number | null];
    parameterB: [number | null, number | null];
    orientation: 1 | -1;
    points: [PathPoint | null, PathPoint | null];
}
export interface IntersectionSet {
    version: 1;
    points: IntersectionPoint[];
    overlaps: IntersectionOverlap[];
    options: Required<IntersectionOptions>;
    pairsTested: number;
}
export interface AdvancedIntersectionOptions extends IntersectionOptions {
    maxWork?: number;
    maxDepth?: number;
}
export interface AdvancedIntersectionReport {
    solver: 'adaptive-cubic-v2';
    cubicPairs: number;
    work: number;
    maxDepthReached: number;
    maxWork: number;
    maxDepth: number;
}
export interface AdvancedIntersectionResult {
    intersections: IntersectionSet;
    report: AdvancedIntersectionReport;
}
export declare function intersectPathGeometries(inputA: DeepReadonly<PathGeometry>, inputB: DeepReadonly<PathGeometry>, configuration?: IntersectionOptions): DeepReadonly<IntersectionSet>;
export declare function intersectPathGeometriesV2(inputA: DeepReadonly<PathGeometry>, inputB: DeepReadonly<PathGeometry>, configuration?: AdvancedIntersectionOptions): DeepReadonly<AdvancedIntersectionResult>;
export declare function assertIntersectionSet(value: unknown): asserts value is IntersectionSet;
