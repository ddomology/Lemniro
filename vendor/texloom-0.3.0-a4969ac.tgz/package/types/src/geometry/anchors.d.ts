import { type DeepReadonly } from '../ir/operations.js';
import { anchorNames, type AnchorName, type AnchorProvider, type AnchorQuery, type TextMetrics } from '../ir/text.js';
import type { PathBounds, PathPoint } from '../path-geometry.js';
import { type Primitive2D } from './primitives.js';
export { anchorNames };
export type { AnchorName, AnchorProvider, AnchorQuery, TextMetrics };
export interface TextAnchorOptions {
    innerSep?: [number, number];
    outerSep?: [number, number];
    revision?: string;
}
export interface MeasuredAnchorOptions {
    logicalBounds?: PathBounds;
    inkBounds?: PathBounds;
    revision?: string;
}
export declare function createShapeAnchorProvider(primitive: DeepReadonly<Primitive2D>, outerSep?: readonly [number, number]): DeepReadonly<AnchorProvider>;
export declare function createTextAnchorProvider(metrics: DeepReadonly<TextMetrics>, inkBounds: readonly [number, number, number, number], options?: DeepReadonly<TextAnchorOptions>): DeepReadonly<AnchorProvider>;
export declare function createMeasuredAnchorProvider(anchors: DeepReadonly<Partial<Record<AnchorName, PathPoint>>>, options?: DeepReadonly<MeasuredAnchorOptions>): DeepReadonly<AnchorProvider>;
export declare function anchorPosition(provider: DeepReadonly<AnchorProvider>, query: DeepReadonly<AnchorQuery>): PathPoint;
