import { type PathGeometry } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
import { type RegularPathFrameOptions } from './path-frame.js';
export type DecorationKind = 'ticks' | 'marks' | 'symbols' | 'snake';
export interface DecorationOptions extends RegularPathFrameOptions {
    kind?: DecorationKind;
    offset?: number;
    size?: number;
    orientation?: 'tangent' | 'fixed' | 'reverse';
    symbolScale?: number;
    amplitude?: number;
    resolution?: number;
}
export interface DecorationReport {
    kind: DecorationKind;
    totalLength: number;
    candidateCount: number;
    emittedCount: number;
    skippedIds: string[];
    sampleIds: string[];
    representation: 'exact' | 'polyline';
}
export interface DecorationResult {
    geometry: PathGeometry;
    report: DecorationReport;
}
export interface BraceOptions {
    amplitude?: number;
    aspect?: number;
    offset?: number;
}
export declare const DECORATION_DEFAULTS: Readonly<Required<DecorationOptions>>;
export declare function normalizeDecorationOptions(value?: DecorationOptions): Required<DecorationOptions>;
export declare function createPathDecoration(input: DeepReadonly<PathGeometry>, configuration?: DecorationOptions, symbol?: DeepReadonly<PathGeometry>): DeepReadonly<DecorationResult>;
export declare function createBraceGeometry(from: readonly [number, number], to: readonly [number, number], configuration?: BraceOptions): DeepReadonly<PathGeometry>;
