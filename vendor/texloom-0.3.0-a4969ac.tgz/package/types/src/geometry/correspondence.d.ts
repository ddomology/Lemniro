import { type PathGeometry, type PathContour } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface SegmentCorrespondence {
    source: string;
    target: string;
}
export interface ContourCorrespondence {
    source: string;
    target: string;
    segments?: SegmentCorrespondence[];
    reverseTarget?: boolean;
}
export interface CorrespondenceOptions {
    approved: true;
    contours: ContourCorrespondence[];
    resample?: {
        count: number;
        tolerance?: number;
    };
    unmatched?: 'error' | 'fade' | 'create';
}
export interface CorrespondencePairReport {
    id: string;
    sourceContour: string;
    targetContour: string;
    reverseTarget: boolean;
    closed: boolean;
    sourceWinding: -1 | 0 | 1;
    targetWinding: -1 | 0 | 1;
    alignedTargetWinding: -1 | 0 | 1;
    representation: 'controls' | 'arc-length-polyline';
    sourceSegments: number;
    targetSegments: number;
    outputSegments: number;
    sourceZeroSegments: number;
    targetZeroSegments: number;
    segments: {
        source: string;
        target: string;
        promotedSource: boolean;
        promotedTarget: boolean;
    }[];
    sampleCount?: number;
    tolerance?: number;
}
export interface CorrespondenceReport {
    version: 1;
    approved: true;
    unmatched: 'error' | 'fade' | 'create';
    pairs: CorrespondencePairReport[];
    sourceOnly: string[];
    targetOnly: string[];
    resampled: boolean;
    outputSegments: number;
    endpointPolicy: 'original-snapshots';
}
export interface PreparedCorrespondence {
    contract: 'texloom-correspondence/1';
    source: PathGeometry;
    target: PathGeometry;
    pairs: {
        id: string;
        sourceContour: string;
        targetContour: string;
        source: PathContour;
        target: PathContour;
    }[];
    sourceOnly: PathContour[];
    targetOnly: PathContour[];
    report: CorrespondenceReport;
}
export interface CorrespondenceSample {
    geometry: PathGeometry;
    matched: PathGeometry;
    sourceOnly: PathGeometry;
    targetOnly: PathGeometry;
    sourceOpacity: number;
    targetOpacity: number;
    sourceReveal: number;
    targetReveal: number;
}
export declare const CORRESPONDENCE_MAX_CONTOURS = 128, CORRESPONDENCE_MAX_SEGMENTS = 8192, CORRESPONDENCE_MAX_SAMPLES = 4096;
export declare function prepareCorrespondence(sourceInput: DeepReadonly<PathGeometry>, targetInput: DeepReadonly<PathGeometry>, options: DeepReadonly<CorrespondenceOptions>): DeepReadonly<PreparedCorrespondence>;
export declare function sampleCorrespondence(prepared: DeepReadonly<PreparedCorrespondence>, progress: number): DeepReadonly<CorrespondenceSample>;
