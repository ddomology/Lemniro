import { type PathGeometry, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface ArrowOptions {
    start?: 0 | 1 | 2;
    end?: 0 | 1 | 2;
    length?: number;
    width?: number;
    inset?: number;
    shortenStart?: number;
    shortenEnd?: number;
    collision?: 'error' | 'clamp';
    tolerance?: number;
}
export declare const ARROW_DEFAULTS: Readonly<Required<ArrowOptions>>;
export interface ArrowEndpointReport {
    endpoint: PathPoint;
    visualTip: PathPoint;
    shaftEndpoint: PathPoint;
    tangent: PathPoint;
}
export interface ArrowReport {
    totalLength: number;
    scale: number;
    shortenStart: number;
    shortenEnd: number;
    shaftTrimStart: number;
    shaftTrimEnd: number;
    start: ArrowEndpointReport;
    end: ArrowEndpointReport;
}
export interface ArrowGeometry {
    shaft: PathGeometry;
    startTip: PathGeometry;
    endTip: PathGeometry;
    report: ArrowReport;
}
export type ArrowGeometryResult = ArrowGeometry;
type ResolvedPath = {
    start: readonly [number, number];
    c1: readonly [number, number];
    c2: readonly [number, number];
    end: readonly [number, number];
};
export declare function normalizeArrowOptions(value?: ArrowOptions): Required<ArrowOptions>;
export declare function createArrowGeometry(input: DeepReadonly<PathGeometry>, configuration?: ArrowOptions): DeepReadonly<ArrowGeometry>;
export declare function legacyArrowPoints(path: ResolvedPath, end: boolean, size?: number): readonly [PathPoint, PathPoint, PathPoint];
export {};
