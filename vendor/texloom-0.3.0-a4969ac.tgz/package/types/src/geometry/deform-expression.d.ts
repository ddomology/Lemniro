import { type DeepReadonly, type SourceSpan } from '../ir/operations.js';
import type { CompiledExpression, ExpressionNode, ExpressionValue, ParameterDefinition } from '../fields/ast.js';
type Ast = DeepReadonly<ExpressionNode>;
export interface CompiledDeformation extends CompiledExpression {
    readonly parameterDefinitions: Readonly<Record<string, DeepReadonly<ParameterDefinition>>>;
}
export interface DeformationLocals {
    position: readonly [number, number];
    parameter: number;
    index?: number;
    count?: number;
}
export declare function deformationError(compiled: CompiledExpression, code: string, message: string, node?: Ast): never;
export declare function compileDeformation(text: string, parameterDefinitions?: Readonly<Record<string, ParameterDefinition>>, sourceSpan?: SourceSpan): CompiledDeformation;
export declare function deformationParameters(compiled: CompiledDeformation, overrides?: Readonly<Record<string, ExpressionValue>>): Record<string, ExpressionValue>;
export declare function evaluateDeformation(compiled: CompiledDeformation, time: number, parameters: Readonly<Record<string, ExpressionValue>>, locals: DeformationLocals): [number, number];
type Affine = [number, number, number];
export declare function affineDeformation(compiled: CompiledDeformation, time: number, parameters: Readonly<Record<string, ExpressionValue>>): readonly [Affine, Affine] | undefined;
export type Interval = readonly [number, number];
export type Rectangle = readonly [Interval, Interval];
export declare class DeformationIntervalUncertain extends Error {
    readonly node: Ast;
    constructor(node: Ast, message: string);
}
export declare function outward(value: number, direction: -1 | 1): number;
export declare function boundDeformation(compiled: CompiledDeformation, position: Rectangle, parameter: Interval, time: number, parameters: Readonly<Record<string, ExpressionValue>>): Rectangle;
export {};
