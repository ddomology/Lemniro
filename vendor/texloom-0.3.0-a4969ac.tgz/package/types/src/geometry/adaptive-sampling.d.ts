import { type PathGeometry, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface AdaptiveSamplingOptions {
    domains: [number, number][];
    breaks?: number[];
    tolerance?: number;
    pixelsPerBp?: number;
    initialSegments?: number;
    maxDepth?: number;
    maxSamples?: number;
    maxSegments?: number;
    maxJump?: number;
}
export interface DataSamplingOptions {
    maxSamples?: number;
    maxSegments?: number;
    maxJump?: number;
}
export interface SamplingGap {
    domain: [number, number];
    reason: 'masked' | 'break';
}
export interface SamplingReport {
    sampleCount: number;
    segmentCount: number;
    contourCount: number;
    maskedIntervals: number;
    maxDepthReached: number;
    maxObservedError: number;
    maxAcceptedError: number;
    qualityMetric: 'observed-probes';
    tolerance: number;
    pixelsPerBp: number;
    gaps: SamplingGap[];
}
export interface SampledPlot {
    geometry: PathGeometry;
    report: SamplingReport;
}
export type CurveEvaluator = (parameter: number) => DeepReadonly<PathPoint> | null;
export declare function adaptiveSampleCurve(evaluate: CurveEvaluator, options: DeepReadonly<AdaptiveSamplingOptions>): DeepReadonly<SampledPlot>;
export declare function areaBetweenCurves(top: CurveEvaluator, bottom: CurveEvaluator, options: DeepReadonly<AdaptiveSamplingOptions>): DeepReadonly<SampledPlot>;
export declare function sampledDataPlot(samples: readonly (DeepReadonly<PathPoint> | null)[], options?: DeepReadonly<DataSamplingOptions>): DeepReadonly<SampledPlot>;
