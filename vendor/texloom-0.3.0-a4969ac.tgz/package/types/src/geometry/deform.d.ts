import { type DeepReadonly } from '../ir/operations.js';
import { type PathGeometry } from '../path-geometry.js';
import type { ExpressionValue } from '../fields/ast.js';
import { type CompiledDeformation } from './deform-expression.js';
export type DeformationMode = 'controlDeform' | 'pointwiseDeform';
export interface DeformationOptions {
    mode: DeformationMode;
    time: number;
    parameters?: Readonly<Record<string, ExpressionValue>>;
    tolerance?: number;
    maxDepth?: number;
    maxSegments?: number;
}
export interface DeformationSegmentReport {
    contourId: string;
    sourceSegmentId: string | null;
    outputSegmentId: string;
    sourceInterval: [number, number];
    parameterInterval: [number, number];
    closing: boolean;
    errorBound: number;
    synthetic?: 'closing-edge';
}
export interface DeformationReport {
    method: 'control' | 'affine-exact' | 'adaptive-polyline';
    sourceSegments: number;
    outputSegments: number;
    maxErrorBound: number;
    tolerance: number;
    subdivisions: number;
    maxDepthReached: number;
    tangentPolicy: 'control-curve' | 'affine-curve' | 'polyline-right-hand';
    boundPolicy: 'exact-control-map' | 'affine-real-arithmetic' | 'interval-image-to-chord';
    precision: 'float64-with-outward-arithmetic-and-libm-guard';
    segments: DeformationSegmentReport[];
}
export interface DeformationResult {
    geometry: DeepReadonly<PathGeometry>;
    report: DeepReadonly<DeformationReport>;
}
export declare function deformGeometry(input: DeepReadonly<PathGeometry>, compiled: CompiledDeformation, options: DeformationOptions): DeformationResult;
