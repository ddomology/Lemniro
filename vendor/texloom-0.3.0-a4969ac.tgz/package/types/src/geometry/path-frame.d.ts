import { type PathGeometry, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface PathFrameOptions {
    tolerance?: number;
    corner?: 'following' | 'skip' | 'error';
    cusp?: 'skip' | 'error';
}
export interface RegularPathFrameOptions extends PathFrameOptions {
    spacing?: number;
    phase?: number;
    origin?: number;
    startMargin?: number;
    endMargin?: number;
    maxSamples?: number;
}
export interface PathFrame {
    position: PathPoint;
    tangent: PathPoint;
    normal: PathPoint;
    distance: number;
    segmentId: string;
    localParameter: number;
}
export interface PathFrameSampler {
    readonly totalLength: number;
    readonly closed: boolean;
    readonly corners: readonly number[];
    readonly breakpoints: readonly number[];
    frameAt(distance: number): DeepReadonly<PathFrame> | undefined;
}
export interface RegularPathFrames {
    frames: (PathFrame & {
        id: string;
        index: number;
    })[];
    skipped: number[];
    totalLength: number;
    closed: boolean;
}
export declare function preparePathFrames(input: DeepReadonly<PathGeometry>, configuration?: PathFrameOptions): PathFrameSampler;
export declare function regularPathFrames(input: DeepReadonly<PathGeometry>, configuration?: RegularPathFrameOptions): DeepReadonly<RegularPathFrames>;
