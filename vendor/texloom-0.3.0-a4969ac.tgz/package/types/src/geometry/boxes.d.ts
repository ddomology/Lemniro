import { type PathBounds, type PathPoint } from '../path-geometry.js';
import type { DeepReadonly } from '../ir/operations.js';
export interface LayoutBox {
    bounds: PathBounds;
    baseline: number;
}
export type BoxList = (LayoutBox | null)[];
export interface BoxLayoutResult {
    positions: PathPoint[];
    bounds: PathBounds;
    rows: number;
    columns: number;
}
export type BoxAlignment = 'start' | 'center' | 'end' | 'baseline';
export interface MatrixBoxOptions {
    origin?: PathPoint;
    columns?: number;
    gapX?: number;
    gapY?: number;
    alignX?: Exclude<BoxAlignment, 'baseline'>;
    alignY?: BoxAlignment;
    maxWidth?: number;
    maxHeight?: number;
    overflow?: 'allow' | 'error';
}
export interface DistributeBoxOptions {
    origin?: PathPoint;
    axis?: 'x' | 'y';
    gap?: number;
    crossGap?: number;
    align?: BoxAlignment;
    maxWidth?: number;
    maxHeight?: number;
    overflow?: 'allow' | 'error' | 'wrap';
}
export interface AlignBoxOptions {
    axis?: 'x' | 'y';
    align?: BoxAlignment;
    at?: number;
}
export interface FitBoxOptions {
    paddingX?: number;
    paddingY?: number;
}
export declare const MAX_BOX_SLOTS = 4096;
export declare function assertBoxList(value: unknown): asserts value is BoxList;
export declare function normalizeMatrixBoxOptions(value?: DeepReadonly<MatrixBoxOptions>): Required<MatrixBoxOptions>;
export declare function normalizeDistributeBoxOptions(value?: DeepReadonly<DistributeBoxOptions>): Required<DistributeBoxOptions>;
export declare function normalizeAlignBoxOptions(value?: DeepReadonly<AlignBoxOptions>): Required<AlignBoxOptions>;
export declare function normalizeFitBoxOptions(value?: DeepReadonly<FitBoxOptions>): Required<FitBoxOptions>;
export declare function matrixBoxLayout(input: DeepReadonly<BoxList>, options?: DeepReadonly<MatrixBoxOptions>): DeepReadonly<BoxLayoutResult>;
export declare function distributeBoxLayout(input: DeepReadonly<BoxList>, options?: DeepReadonly<DistributeBoxOptions>): DeepReadonly<BoxLayoutResult>;
export declare function fitBoxBounds(input: DeepReadonly<BoxList>, translations: DeepReadonly<PathPoint[]>, options?: DeepReadonly<FitBoxOptions>): DeepReadonly<PathBounds>;
export declare function alignBoxLayout(input: DeepReadonly<BoxList>, translations: DeepReadonly<PathPoint[]>, options?: DeepReadonly<AlignBoxOptions>): DeepReadonly<BoxLayoutResult>;
