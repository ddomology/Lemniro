import type { Bundle, Relation } from '../schema.js';
import type { SourceSpan } from './operations.js';
import { type PropertyAccess } from '../operations/properties.js';
export interface LoweredRelation {
    id: string;
    operator: string;
    version: 1;
    relation: Relation;
    path: string;
    sourceSpan?: SourceSpan;
    reads: PropertyAccess[];
    writes: PropertyAccess[];
    dependencies: string[];
}
export declare function lowerRelations(bundle: Bundle): LoweredRelation[];
