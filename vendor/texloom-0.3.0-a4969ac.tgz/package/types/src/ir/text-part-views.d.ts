import { type Bundle } from '../schema.js';
import { type SourceSpan, type DeepReadonly } from './operations.js';
import { type TextPartQuery } from './text-parts.js';
export interface TextPartViewRecord {
    id: string;
    sourceId: string;
    query: TextPartQuery;
    style?: {
        fill?: string;
        opacity?: number;
    };
    sourceSpan?: SourceSpan;
}
export declare function lowerTextPartViews(bundle: Bundle, records: DeepReadonly<TextPartViewRecord[]>): Bundle;
