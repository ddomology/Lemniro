import { type VectorResource, type PaintItem, type Matrix, type Style, type Clip } from '../schema.js';
import { type Diagnostic, type DeepReadonly, type SourceSpan } from './operations.js';
import type { PathBounds } from '../path-geometry.js';
export type PaintAddress = number[];
export interface TextPart {
    id: string;
    parent?: string;
    role?: string;
    sourceRange?: {
        start: number;
        end: number;
    };
    sourceSpan?: SourceSpan;
    paintPaths: PaintAddress[];
    logicalBox?: PathBounds;
}
export interface TextParts {
    version: 1;
    parts: TextPart[];
}
export interface TextPartQuery {
    ids: string[];
    scope: 'exact' | 'descendants';
    overlap: 'error' | 'ancestor-wins';
}
export interface TextPartPaintAncestor {
    paintPath: PaintAddress;
    transform?: Matrix;
    style?: Style;
    clip?: Clip & {
        transform?: Matrix;
    };
}
export interface TextPartPaintLeaf {
    partId: string;
    paintPath: PaintAddress;
    item: PaintItem;
    ancestors: TextPartPaintAncestor[];
    transform: Matrix;
}
export interface TextPartSelection {
    requestedIds: string[];
    partIds: string[];
    parts: TextPart[];
    paintPaths: PaintAddress[];
    items: PaintItem[];
    leaves: TextPartPaintLeaf[];
}
export declare const TEXT_PART_MAX_PARTS = 4096, TEXT_PART_MAX_PAINT_PATHS = 65536, TEXT_PART_MAX_DEPTH = 64;
type PartResource = VectorResource & {
    textParts?: TextParts;
};
export declare function validateTextParts(input: unknown, resource: unknown, path?: string): Diagnostic[];
export declare function validateTextPartsInContext(input: unknown, resource: VectorResource, path?: string): Diagnostic[];
export declare function selectTextParts(resource: DeepReadonly<PartResource>, query: DeepReadonly<TextPartQuery>): DeepReadonly<TextPartSelection>;
export {};
