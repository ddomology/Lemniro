export type PathPoint = [number, number];
export type PathMatrix = [number, number, number, number, number, number];
export type PathSegment = {
    kind: 'line';
    id: string;
    to: PathPoint;
} | {
    kind: 'cubic';
    id: string;
    c1: PathPoint;
    c2: PathPoint;
    to: PathPoint;
};
export interface PathContour {
    id: string;
    start: PathPoint;
    segments: PathSegment[];
    closed?: boolean;
}
export interface PathGeometry {
    contours: PathContour[];
}
export type PathProgressMode = 'parameter' | 'length';
export type PathBounds = [number, number, number, number];
export interface PathSample {
    point: PathPoint;
    tangent: PathPoint;
    contourId: string;
    segmentId: string;
    localParameter: number;
}
export declare class PathGeometryError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export declare function evaluateSegment(start: PathPoint, segment: PathSegment, t: number): PathPoint;
export declare function derivativeSegment(start: PathPoint, segment: PathSegment, t: number): PathPoint;
export declare function splitSegment(start: PathPoint, segment: PathSegment, t: number): [PathSegment, PathSegment];
export declare function pathGeometryData(geometry: PathGeometry): string;
export declare function geometryBounds(geometry: PathGeometry): PathBounds | null;
export declare function transformGeometry(geometry: PathGeometry, matrix: PathMatrix): PathGeometry;
export declare function geometryLength(geometry: PathGeometry, tolerance?: number): number;
export declare function sampleGeometry(geometry: PathGeometry, progress: number, mode?: PathProgressMode, tolerance?: number): PathSample;
export declare function revealGeometry(geometry: PathGeometry, progress: number, mode?: PathProgressMode, tolerance?: number): PathGeometry;
