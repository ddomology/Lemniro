import { type DeepReadonly, type OperatorDefinition } from '../ir/operations.js';
export interface OperatorRegistry {
    get(name: string, version: number): DeepReadonly<OperatorDefinition> | undefined;
    list(): readonly DeepReadonly<OperatorDefinition>[];
}
export declare function createOperatorRegistry(definitions: readonly OperatorDefinition[]): OperatorRegistry;
export declare const defaultOperatorRegistry: OperatorRegistry;
