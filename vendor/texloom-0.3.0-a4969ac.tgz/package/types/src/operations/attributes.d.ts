import { type DeepReadonly } from '../ir/operations.js';
import type { ExpressionType } from '../fields/ast.js';
import type { FieldAttribute, FieldContext } from '../fields/types.js';
export declare function assertFieldType(type: DeepReadonly<ExpressionType>, path?: string): void;
export declare function fieldTypesEqual(a: DeepReadonly<ExpressionType>, b: DeepReadonly<ExpressionType>): boolean;
export declare function assertCompatibleAttribute(context: DeepReadonly<FieldContext>, attribute: DeepReadonly<FieldAttribute>): void;
export declare function captureAttribute(context: DeepReadonly<FieldContext>, attribute: DeepReadonly<FieldAttribute>): DeepReadonly<FieldAttribute>;
export declare function setFieldPositions(context: DeepReadonly<FieldContext>, attribute: DeepReadonly<FieldAttribute>): DeepReadonly<FieldContext>;
