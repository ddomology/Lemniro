import type { Bundle, Node } from '../schema.js';
import { type DeepReadonly, type InputRef, type LiteralValue } from '../ir/operations.js';
import { type LayoutBox } from '../geometry/boxes.js';
import type { PropertyAccess } from './properties.js';
type BoxesInput = DeepReadonly<Extract<InputRef, {
    kind: 'boxes';
}>>;
export declare function measureNodeBox(node: Node | undefined, resources: Bundle['resources']): LayoutBox;
export declare function boxInputReads(input: BoxesInput, nodes: ReadonlyMap<string, Node>): PropertyAccess[];
export declare function resolveBoxesInput(input: BoxesInput, nodes: ReadonlyMap<string, Node>, resources: Bundle['resources']): LiteralValue;
export {};
