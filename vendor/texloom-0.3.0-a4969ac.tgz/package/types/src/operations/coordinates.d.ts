import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const coordinateOperatorDefinitions: OperatorDefinition[];
export declare function isCoordinateOperator(name: string, version: number): boolean;
type Inputs = Readonly<Record<string, LiteralValue>>;
type Authored = DeepReadonly<Operation>;
export declare function executeCoordinateOperation(operation: Authored, inputs: Inputs): Record<string, LiteralValue> | undefined;
export {};
