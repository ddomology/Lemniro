import type { DeepReadonly, Diagnostic } from '../ir/operations.js';
export declare function validateJsonData(input: unknown, path?: string): Diagnostic[];
export declare function validateSpaceRef(input: unknown, path?: string): Diagnostic[];
export declare function validateSourceSpan(input: unknown, path?: string): Diagnostic[];
export declare function validateLiteralValue(input: unknown, path?: string): Diagnostic[];
export declare function freezeSnapshot<T>(value: T): DeepReadonly<T>;
