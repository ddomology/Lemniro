import { type Bundle, type Node } from '../schema.js';
import { type Diagnostic, type DeepReadonly, type SourceSpan, type SpaceRef, type InputRef, type LiteralValue } from '../ir/operations.js';
import { type PropertyAccess } from './properties.js';
import type { ExpressionValue } from '../fields/ast.js';
import { type SamplingReport } from '../geometry/adaptive-sampling.js';
import type { AnchorEvaluation } from './anchors.js';
export type PlotMode = 'function' | 'parametric' | 'samples' | 'area';
export interface PlotOperation {
    id: string;
    target: string;
    mode: PlotMode;
    space: SpaceRef;
    inputs: Record<string, InputRef>;
    expression?: string;
    xExpression?: string;
    yExpression?: string;
    lower?: string;
    upper?: string;
    mask?: string;
    domains?: [number, number][];
    breaks?: number[];
    samples?: ([number, number] | null)[];
    sourceSpan?: SourceSpan;
    expressionSpans?: Record<string, SourceSpan>;
}
export interface PlotProgram {
    version: 1;
    operations: PlotOperation[];
}
export type PlotEvaluation = Readonly<Record<string, DeepReadonly<SamplingReport>>>;
export interface PreparedPlot {
    readonly operation: DeepReadonly<PlotOperation>;
    readonly path: string;
    readonly reads: readonly PropertyAccess[];
    readonly writes: readonly PropertyAccess[];
    readonly dependencies: readonly string[];
    apply(nodes: Map<string, Node>, time: number, parameters: Readonly<Record<string, ExpressionValue>>, outputs: ReadonlyMap<string, Record<string, LiteralValue>>, anchors?: AnchorEvaluation): DeepReadonly<SamplingReport>;
}
export interface PreparedPlotProgram {
    readonly operations: readonly PreparedPlot[];
}
export declare function validatePlotProgram(input: unknown, bundle: Bundle): Diagnostic[];
export declare function validatePlotProgramInContext(input: unknown, bundle: Bundle): Diagnostic[];
export declare function preparePlotProgram(input: PlotProgram, bundle: Bundle): PreparedPlotProgram;
