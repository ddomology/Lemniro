import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const pathLabelOperatorDefinitions: OperatorDefinition[];
export declare const isPathLabelOperator: (name: string, version: number) => boolean;
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executePathLabelOperation(op: Authored, inputs: Inputs): Record<string, LiteralValue> | undefined;
export {};
