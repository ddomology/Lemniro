import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const axesOperatorDefinitions: OperatorDefinition[];
export declare const isAxesOperator: (name: string, version: number) => boolean;
export declare function executeAxesOperation(op: DeepReadonly<Operation>, values: Readonly<Record<string, LiteralValue>>): Record<string, LiteralValue> | undefined;
