import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition, type SpaceRef } from '../ir/operations.js';
import { type Primitive2D, type PrimitivePathReport } from '../geometry/primitives.js';
export declare const shapeOperatorDefinitions: OperatorDefinition[];
export declare const isShapeOperator: (name: string, version: number) => boolean;
export interface ShapeEvaluation {
    definitions: Record<string, {
        space: SpaceRef;
        primitive: Primitive2D;
    }>;
    approximations: Record<string, {
        space: SpaceRef;
        report: PrimitivePathReport;
    }>;
}
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executeShapeOperation(op: Authored, inputs: Inputs, metadata?: ShapeEvaluation): Record<string, LiteralValue> | undefined;
export {};
