import type { Bundle, Node, VectorResource } from '../schema.js';
import { type AnchorInput, type TextPlacementInput, type TextAnchorInput, type DeepReadonly, type InputRef, type LiteralValue, type OutputRef, type SpaceRef, type Diagnostic, type SourceSpan } from '../ir/operations.js';
import { type AnchorProvider } from '../ir/text.js';
import type { InputValueType } from './inputs.js';
import type { PropertyAccess } from './properties.js';
type AnchorRef = DeepReadonly<AnchorInput | TextPlacementInput | TextAnchorInput>;
type Obj = Record<string, any>;
export interface AnchorEvaluationEntry {
    provider: DeepReadonly<AnchorProvider>;
    space: SpaceRef;
    position: [number, number];
}
export type AnchorEvaluation = Record<string, AnchorEvaluationEntry>;
export declare function textResourceRevision(resource: VectorResource): string;
export declare function validateAnchorInput(raw: Obj, bundle: Bundle, path: string, span: SourceSpan | undefined, resolve: (raw: unknown, path: string) => InputValueType | undefined): {
    diagnostics: Diagnostic[];
    type?: InputValueType;
};
export declare function anchorInputReads(input: AnchorRef, nodes: ReadonlyMap<string, Node>, outputSpace: (ref: DeepReadonly<OutputRef>) => SpaceRef): PropertyAccess[];
export declare function resolveAnchorInput(input: AnchorRef, nodes: ReadonlyMap<string, Node>, resources: Bundle['resources'], resolve: (input: DeepReadonly<InputRef>, path: string) => LiteralValue, path: string, metadata?: AnchorEvaluation): LiteralValue;
export {};
