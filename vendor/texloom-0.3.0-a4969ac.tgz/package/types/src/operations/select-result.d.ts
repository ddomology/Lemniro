import type { DeepReadonly } from '../ir/operations.js';
import type { IntersectionIncident, IntersectionPoint } from '../geometry/intersections.js';
export declare function compareIntersectionIncidents(a: DeepReadonly<IntersectionIncident>, b: DeepReadonly<IntersectionIncident>, along: 'a' | 'b'): number;
export declare function orderedIntersectionPoints(points: DeepReadonly<IntersectionPoint[]>, along: 'a' | 'b'): {
    point: {
        readonly point: readonly [number, number];
        readonly incidents: readonly {
            readonly a: {
                readonly contourId: string;
                readonly segmentId: string;
                readonly contourIndex: number;
                readonly segmentIndex: number;
                readonly closing: boolean;
            };
            readonly b: {
                readonly contourId: string;
                readonly segmentId: string;
                readonly contourIndex: number;
                readonly segmentIndex: number;
                readonly closing: boolean;
            };
            readonly parameterA: number;
            readonly parameterB: number;
            readonly contact: import("../geometry/intersections.js").IntersectionContact;
        }[];
    };
    incident: {
        readonly a: {
            readonly contourId: string;
            readonly segmentId: string;
            readonly contourIndex: number;
            readonly segmentIndex: number;
            readonly closing: boolean;
        };
        readonly b: {
            readonly contourId: string;
            readonly segmentId: string;
            readonly contourIndex: number;
            readonly segmentIndex: number;
            readonly closing: boolean;
        };
        readonly parameterA: number;
        readonly parameterB: number;
        readonly contact: import("../geometry/intersections.js").IntersectionContact;
    };
}[];
