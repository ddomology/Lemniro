import type { Bundle, Node } from '../schema.js';
import { type DeepReadonly, type Diagnostic, type InputRef, type LiteralValue, type Operation, type OperatorDefinition, type SourceSpan, type SpaceRef } from '../ir/operations.js';
import type { ExpressionValue, Unit } from '../fields/ast.js';
import { type PropertyAccess } from './properties.js';
import { type AnchorEvaluation } from './anchors.js';
export interface InputValueType {
    type: string;
    unit?: Unit;
    role?: string;
    space?: SpaceRef;
    from?: SpaceRef;
    to?: SpaceRef;
}
export declare function hasTransformWriter(chain: ReadonlySet<string>, bundle: Bundle): boolean;
export declare function validateDynamicInput(raw: unknown, bundle: Bundle, path: string, span?: SourceSpan, resolveInput?: (raw: unknown, path: string) => InputValueType | undefined): {
    diagnostics: Diagnostic[];
    type?: InputValueType;
};
export declare function flattenOperationInputs(inputs: Readonly<Record<string, DeepReadonly<InputRef>>>): DeepReadonly<InputRef>[];
export interface PreparedOperationInputs {
    readonly reads: readonly PropertyAccess[];
    resolve(nodes: Map<string, Node>, time: number, parameters: Readonly<Record<string, ExpressionValue>>, outputs: ReadonlyMap<string, Record<string, LiteralValue>>, anchors?: AnchorEvaluation): Record<string, LiteralValue>;
}
export declare function prepareOperationInputs(operation: DeepReadonly<Operation>, bundle: Bundle, path: string, definitions: readonly DeepReadonly<OperatorDefinition>[]): PreparedOperationInputs;
