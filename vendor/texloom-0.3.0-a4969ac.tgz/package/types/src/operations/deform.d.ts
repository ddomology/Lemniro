import { type Bundle, type Node } from '../schema.js';
import { type Diagnostic, type DeepReadonly, type SourceSpan } from '../ir/operations.js';
import { type PropertyAccess } from './properties.js';
import { type CompiledDeformation } from '../geometry/deform-expression.js';
import { type DeformationReport, type DeformationMode } from '../geometry/deform.js';
import type { ExpressionValue } from '../fields/ast.js';
export interface DeformationOperation {
    id: string;
    source: string;
    target: string;
    mode: DeformationMode;
    expression: string;
    tolerance?: number;
    maxDepth?: number;
    maxSegments?: number;
    sourceSpan?: SourceSpan;
}
export interface DeformationProgram {
    version: 1;
    operations: DeformationOperation[];
}
export type DeformationEvaluation = Readonly<Record<string, DeepReadonly<DeformationReport>>>;
export interface PreparedDeformation {
    readonly operation: DeepReadonly<DeformationOperation>;
    readonly expression: CompiledDeformation;
    readonly path: string;
    readonly reads: readonly PropertyAccess[];
    readonly writes: readonly PropertyAccess[];
    apply(nodes: Map<string, Node>, time: number, parameters: Readonly<Record<string, ExpressionValue>>): DeepReadonly<DeformationReport>;
}
export interface PreparedDeformationProgram {
    readonly operations: readonly PreparedDeformation[];
}
export declare function deformationWrites(target: string): PropertyAccess[];
export declare function validateDeformationProgram(input: unknown, bundle: Bundle): Diagnostic[];
export declare function validateDeformationProgramInContext(input: unknown, bundle: Bundle): Diagnostic[];
export declare function prepareDeformationProgram(input: DeformationProgram, bundle: Bundle): PreparedDeformationProgram;
