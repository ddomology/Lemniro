import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const connectorOperatorDefinitions: OperatorDefinition[];
export declare const isConnectorOperator: (name: string, version: number) => boolean;
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executeConnectorOperation(op: Authored, inputs: Inputs): Record<string, LiteralValue> | undefined;
export {};
