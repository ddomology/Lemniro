import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition, type SpaceRef } from '../ir/operations.js';
import { sampleCurveGeometry, type CurveProvenance, type CurveReport } from '../geometry/curves.js';
export declare const curveOperatorDefinitions: OperatorDefinition[];
export declare const isCurveOperator: (name: string, version: number) => boolean;
export interface CurveEvaluation {
    operations: Record<string, {
        space: SpaceRef;
        report: DeepReadonly<CurveReport>;
        provenance: DeepReadonly<CurveProvenance>;
    }>;
    samples: Record<string, {
        space: SpaceRef;
        sample: ReturnType<typeof sampleCurveGeometry>;
    }>;
}
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executeCurveOperation(op: Authored, inputs: Inputs, metadata?: CurveEvaluation): Record<string, LiteralValue> | undefined;
export {};
