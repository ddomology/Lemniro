import type { VectorResource, PaintItem } from '../schema.js';
import { type DeepReadonly } from '../ir/operations.js';
import { type TextPartSelection, type PaintAddress } from '../ir/text-parts.js';
export type MathPartAnchor = [number, number] | 'logical-center';
export interface MathPartMapping {
    source: string;
    target: string;
    mode: 'replace' | 'copy';
    sourceAnchor: MathPartAnchor;
    targetAnchor: MathPartAnchor;
}
export interface MathCorrespondenceOptions {
    approved: true;
    retention: 'replace' | 'keep-source';
    pairs: MathPartMapping[];
    unmatched: 'error' | 'fade';
}
export interface NativePaintPartition {
    items: PaintItem[];
    paintPaths: PaintAddress[];
}
export interface PreparedMathPair {
    id: string;
    sourcePartId: string;
    targetPartId: string;
    mode: 'replace' | 'copy';
    sourceAnchor: [number, number];
    targetAnchor: [number, number];
    sourceSelection: TextPartSelection;
    targetSelection: TextPartSelection;
    sourceText?: string;
    targetText?: string;
}
export interface MathCorrespondenceReport {
    version: 1;
    approved: true;
    retention: 'replace' | 'keep-source';
    unmatched: 'error' | 'fade';
    sourcePaintLeaves: number;
    targetPaintLeaves: number;
    sourceMappedPaintLeaves: number;
    targetMappedPaintLeaves: number;
    sourceRemainderPaintLeaves: number;
    targetRemainderPaintLeaves: number;
    sourceUses: {
        sourcePartId: string;
        replacePairs: string[];
        copyPairs: string[];
        paintLeaves: number;
    }[];
    pairs: {
        id: string;
        sourcePartId: string;
        targetPartId: string;
        mode: 'replace' | 'copy';
        sourcePartIds: string[];
        targetPartIds: string[];
        sourcePaintLeaves: number;
        targetPaintLeaves: number;
        sourceAnchor: [number, number];
        targetAnchor: [number, number];
        sourceAnchorPolicy: 'explicit' | 'logical-center';
        targetAnchorPolicy: 'explicit' | 'logical-center';
    }[];
    endpointPolicy: 'native-resources';
}
export interface PreparedMathCorrespondence {
    contract: 'texloom-math-correspondence/1';
    retention: 'replace' | 'keep-source';
    unmatched: 'error' | 'fade';
    source: VectorResource;
    target: VectorResource;
    pairs: PreparedMathPair[];
    sourceRemainder: NativePaintPartition;
    targetRemainder: NativePaintPartition;
    report: MathCorrespondenceReport;
}
export declare const MATH_PART_MAX_PAIRS = 256;
export declare function prepareMathCorrespondence(source: DeepReadonly<VectorResource>, target: DeepReadonly<VectorResource>, options: DeepReadonly<MathCorrespondenceOptions>): DeepReadonly<PreparedMathCorrespondence>;
