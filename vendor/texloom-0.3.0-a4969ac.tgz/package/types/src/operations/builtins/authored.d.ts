import { type DeepReadonly, type LiteralValue, type Operation } from '../../ir/operations.js';
import { type ShapeEvaluation } from '../shapes.js';
import { type CurveEvaluation } from '../curves.js';
import { type IntersectionEvaluation } from '../intersections.js';
type AuthoredOperation = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function requireAuthoredImplementation(name: string, version: number): void;
export declare function executeAuthoredOperation(operation: AuthoredOperation, inputs: Inputs, shapes?: ShapeEvaluation, curves?: CurveEvaluation, intersections?: IntersectionEvaluation): Record<string, LiteralValue>;
export {};
