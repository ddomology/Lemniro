import type { Bundle, Node, Relation } from '../../schema.js';
import { type Point } from '../../geometry.js';
export interface LegacyFrameContext {
    nodes: Map<string, Node>;
    resources: Bundle['resources'];
    samples: Map<string, {
        source: string;
        tangent: Point;
    }>;
}
export interface LegacyOperator {
    name: string;
    version: 1;
    execute: (relation: Relation, context: LegacyFrameContext) => void;
}
export declare function withPathContext<T>(id: string, fn: () => T): T;
export declare function getLegacyOperator(type: Relation['type']): LegacyOperator;
export declare function executeLegacyOperation(relation: Relation, context: LegacyFrameContext): void;
