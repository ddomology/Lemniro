import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const constraintOperatorDefinitions: OperatorDefinition[];
export declare const isConstraintOperator: (name: string, version: number) => boolean;
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executeConstraintOperation(operation: Authored, inputs: Inputs): Record<string, LiteralValue> | undefined;
export {};
