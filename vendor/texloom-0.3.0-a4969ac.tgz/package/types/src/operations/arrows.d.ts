import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const arrowOperatorDefinitions: OperatorDefinition[];
export declare const isArrowOperator: (name: string, version: number) => boolean;
export declare function executeArrowOperation(op: DeepReadonly<Operation>, values: Readonly<Record<string, LiteralValue>>): Record<string, LiteralValue> | undefined;
