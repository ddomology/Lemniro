import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const decorationOperatorDefinitions: OperatorDefinition[];
export declare const isDecorationOperator: (name: string, version: number) => boolean;
export declare function executeDecorationOperation(op: DeepReadonly<Operation>, values: Readonly<Record<string, LiteralValue>>): Record<string, LiteralValue> | undefined;
