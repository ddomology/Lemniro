import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition, type SpaceRef } from '../ir/operations.js';
import { type AdvancedIntersectionReport, type IntersectionSet } from '../geometry/intersections.js';
export declare const intersectionOperatorDefinitions: OperatorDefinition[];
export declare const isIntersectionOperator: (name: string, version: number) => boolean;
type PointResult = IntersectionSet['points'][number];
type Incident = PointResult['incidents'][number];
export interface IntersectionEvaluation {
    sets: Record<string, {
        space: SpaceRef;
        result: DeepReadonly<IntersectionSet>;
        report?: DeepReadonly<AdvancedIntersectionReport>;
    }>;
    selections: Record<string, {
        space: SpaceRef;
        along: 'a' | 'b';
        index: number;
        selected: DeepReadonly<PointResult> | null;
        incident: DeepReadonly<Incident> | null;
    }>;
}
type Authored = DeepReadonly<Operation>;
type Inputs = Readonly<Record<string, LiteralValue>>;
export declare function executeIntersectionOperation(op: Authored, inputs: Inputs, metadata?: IntersectionEvaluation): Record<string, LiteralValue> | undefined;
export {};
