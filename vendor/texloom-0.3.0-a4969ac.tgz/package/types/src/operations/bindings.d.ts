import type { Camera, Node } from '../schema.js';
import type { LiteralValue, DeepReadonly, OperationBinding } from '../ir/operations.js';
export declare function applyOperationBinding(binding: DeepReadonly<OperationBinding>, value: LiteralValue, nodes: Map<string, Node>, camera: Camera): void;
