import type { Bundle } from '../schema.js';
import { type Diagnostic, type PreparedOperationGraph } from '../ir/operations.js';
import { type OperatorRegistry } from './registry.js';
export declare function validateOperationGraph(graph: unknown, bundle: Bundle, registry?: OperatorRegistry): Diagnostic[];
export declare function validateOperationGraphInContext(graph: unknown, bundle: Bundle, registry?: OperatorRegistry): Diagnostic[];
export declare function prepareOperationGraph(graph: unknown, bundle: Bundle, registry?: OperatorRegistry): PreparedOperationGraph;
