import { type Bundle, type Camera, type Node } from '../schema.js';
import { type SourceSpan, type DeepReadonly } from '../ir/operations.js';
import { type PropertyAccess } from './properties.js';
import type { ExpressionValue } from '../fields/ast.js';
import type { FieldEvaluation } from '../fields/types.js';
import { type DeformationEvaluation } from './deform.js';
import { type ShapeEvaluation } from './shapes.js';
import type { AnchorEvaluation } from './anchors.js';
import { type CurveEvaluation } from './curves.js';
import { type IntersectionEvaluation } from './intersections.js';
import { type PlotEvaluation } from './plot.js';
import { type MorphEvaluation } from '../timeline/morph.js';
import { type MathTransformEvaluation } from '../timeline/math-transform.js';
import type { TraceEvaluation } from '../timeline/trace.js';
export interface ExecutionMetadata {
    deformations?: DeformationEvaluation;
    plots?: PlotEvaluation;
    morphs?: MorphEvaluation;
    mathTransforms?: MathTransformEvaluation;
    traces?: TraceEvaluation;
    shapes?: ShapeEvaluation;
    anchors?: AnchorEvaluation;
    curves?: CurveEvaluation;
    intersections?: IntersectionEvaluation;
}
export interface ExecutionAccess {
    id: string;
    path: string;
    sourceSpan?: SourceSpan;
    reads: PropertyAccess[];
    writes: PropertyAccess[];
}
export interface ExecutionPlan {
    readonly contract: 'texloom-execution/1';
    readonly order: readonly string[];
    readonly accesses: readonly DeepReadonly<ExecutionAccess>[];
    execute(nodes: Map<string, Node>, resources: Bundle['resources'], camera: Camera, time: number, parameters?: Readonly<Record<string, ExpressionValue>>, metadata?: ExecutionMetadata): FieldEvaluation | undefined;
}
export declare function prepareExecutionPlan(input: Bundle): ExecutionPlan;
