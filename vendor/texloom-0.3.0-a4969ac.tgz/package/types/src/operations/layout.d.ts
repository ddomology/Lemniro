import { type DeepReadonly, type LiteralValue, type Operation, type OperatorDefinition } from '../ir/operations.js';
export declare const layoutOperatorDefinitions: OperatorDefinition[];
export declare const isLayoutOperator: (name: string, version: number) => boolean;
export declare function executeLayoutOperation(op: DeepReadonly<Operation>, values: Readonly<Record<string, LiteralValue>>): Record<string, LiteralValue> | undefined;
