import type { Node } from '../schema.js';
import type { OperationBinding } from '../ir/operations.js';
import type { Unit } from '../fields/ast.js';
export declare function scalarPropertyUnit(property: string): Unit;
export interface PropertyAccess {
    node: string;
    property: string;
}
export declare function propertiesOverlap(a: PropertyAccess, b: PropertyAccess): boolean;
export declare function bindingProperties(binding: Pick<OperationBinding, 'target' | 'property'>, nodes: ReadonlyMap<string, Node>): PropertyAccess[];
export declare function transformReads(id: string | undefined, nodes: ReadonlyMap<string, Node>): PropertyAccess[];
