import type { EvaluatedFrame } from './index.js';
export interface SvgOptions {
    background?: string;
    width?: number;
    height?: number;
    idPrefix?: string;
}
export declare function fieldColor(value: number, range: readonly number[]): string;
export declare function renderSvg(frame: EvaluatedFrame, options?: SvgOptions): string;
