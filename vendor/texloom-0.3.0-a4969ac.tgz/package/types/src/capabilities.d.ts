import type { Bundle } from './schema.js';
export declare const VECTOR_2D_FEATURES: readonly ['path.2d', 'primitive.2d', 'tex.outlines', 'field.scalar-grid.2d', 'transform.affine.2d', 'paint.clip', 'paint.opacity', 'paint.dash', 'paint.current-color', 'path.arrowheads'];
export type RenderFeature = typeof VECTOR_2D_FEATURES[number];
export interface CapabilityProfile {
    readonly id: string;
    readonly contract: 'texloom-render/1';
    readonly features: readonly string[];
}
export declare const SVG_2D_PROFILE: CapabilityProfile;
export declare const CANVAS_2D_PROFILE: CapabilityProfile;
export interface CapabilityReport {
    profile: string;
    compatible: boolean;
    required: string[];
    unsupported: string[];
}
export declare function checkCapabilities(required: readonly string[], profile: CapabilityProfile): CapabilityReport;
export declare function requireCapabilities(required: readonly string[], profile: CapabilityProfile): CapabilityReport;
export declare function sceneFeatures(bundle: Bundle): RenderFeature[];
