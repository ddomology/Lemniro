import type { Bundle } from '../src/index.js';
export * from './lemniro-figure.js';
export declare function renderLemniroFigure(bundle: Bundle, time?: number, caption?: string, instanceId?: string): string;
export declare function renderLemniroPlayer(playerUrl: string, title?: string): string;
