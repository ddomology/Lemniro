import { type SceneManifest } from '../src/runtime.js';
import type { DeepReadonly, Diagnostic } from '../src/ir/operations.js';
import type { EvaluatedFrame } from '../src/schema.js';
export interface LemniroFigureReference {
    contract: 'texloom-figure/1';
    id: string;
    manifestPath: string;
    manifestSha256: string;
    posterPath: string;
    title: string;
    description: string;
    width: number;
    height: number;
    duration: number;
}
export declare class LemniroFigureError extends Error {
    readonly code: string;
    readonly diagnostics: DeepReadonly<Diagnostic[]>;
    constructor(code: string, message: string, diagnostics?: readonly Diagnostic[]);
}
export declare function isPortableFigurePath(value: unknown): value is string;
export declare function validateLemniroFigureReference(input: unknown): Diagnostic[];
export declare function assertLemniroFigureReference(input: unknown): asserts input is LemniroFigureReference;
export interface LemniroFigureOptions {
    baseUrl: string | URL;
    instanceId: string;
    signal?: AbortSignal;
    fetch?: typeof globalThis.fetch;
}
export interface LemniroFigureRuntime {
    readonly manifest: SceneManifest;
    readonly state: 'ready' | 'disposed';
    sample(seconds: number): EvaluatedFrame;
    render(seconds: number): string;
    dispose(): void;
}
export declare function prepareLemniroFigure(input: LemniroFigureReference, options: LemniroFigureOptions): Promise<LemniroFigureRuntime>;
